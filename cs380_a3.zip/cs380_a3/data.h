#ifndef DATA_H
#define DATA_H

namespace AI 
{


}

#endif