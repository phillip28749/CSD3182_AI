#include "functions.h"

namespace AI 
{


} 